COMO RODAR O PROJETO BAIXADO
Verificar se está instalado o Composer
### composer

Instalar todas as dependencias indicada pelo package.json
### composer install

Rodar o projeto com PHP, para executar é necessário acessar o diretório api através do terminal ou prompt de comando
### php servidor_chat.php


SEQUENCIA PARA CRIAR O PROJETO
Verificar se está instalado o Composer
### composer

Instalar a dependencias Ratchet, biblioteca PHP que permite criar aplicativos de tempo real baseados em WebSockets
### composer require cboden/ratchet

Rodar o projeto com PHP, para executar é necessário acessar o diretório api através do terminal ou prompt de comando
### php servidor_chat.php